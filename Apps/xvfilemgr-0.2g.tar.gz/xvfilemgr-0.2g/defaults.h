/* defaults.h.  Generated automatically by configure.  */
