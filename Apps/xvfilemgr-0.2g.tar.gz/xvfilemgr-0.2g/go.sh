#!/bin/sh
export CFLAGS="-pipe -g -Wall"
./configure
