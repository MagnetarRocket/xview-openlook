#ifndef _OLWM_LBL_CURSORS_H
#define _OLWM_LBL_CURSORS_H

#ifdef IDENT
#ident "@(#)cursors.h	1.1 olvwm version 09/22/03"
#endif

extern void InitCursors( /* Display *,  ScreenInfo * */ );
extern void updateCursors( /* Display *, char * */ );

#endif
