#!/bin/sh
#
# (c) 2005 Martin Gr�fe
# AuM.Graefe@t-online.de

if [ -d /usr/openwin/include ]; then
  echo "XView is already installed (/usr/openwin/)."
  exit
fi

SRC_PATH="$PWD"

cd /usr
echo "extracting XView files..."
tar -xzf "$SRC_PATH/openwin.tgz"

echo "creating symbolic links..."
if [ ! -e /usr/lib/libxview.so ]; then
  ln -s /usr/openwin/lib/libxview.so /usr/lib/libxview.so
fi
if [ ! -e /usr/lib/libolgx.so ]; then
  ln -s /usr/openwin/lib/libolgx.so /usr/lib/libolgx.so
fi

echo "done."
echo ""
echo "Please add '/usr/openwin/man' to your man path."

cd "$SRC_PATH"
