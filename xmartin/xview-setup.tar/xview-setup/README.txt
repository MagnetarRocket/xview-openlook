
		XView and OpenLook
		==================

This package provides the neccessary libraries and include files
for building and running XView applications. It contains:

	libxview (Version 3.2 with some bug fixes from 2004)
	libolgx
	/usr/openwin/include/*
	/usr/openwin/bin/*
	/usr/openwin/lib/locale/* (translations files)
	/usr/openwin/man/*
	XView.html (general information)

To install the files at the suitable directories simply run the
bash-script "xview.sh" (as root):

     > su
     Password:
     # ./xview.sh
     # exit
     >

Furthermore a text file named "messages.po" is included in this
package. It contains all the libxview messages that could be
translated into other languages (more than 600 strings). You'll
find a german version in
/usr/openwin/share/locale/de/LC_MESSAGES/SUNW_WST_LIBXVIEW_3200.po
which contains translations only of some of these messages.
To make the libxview "multilingual" fill in the translations,
then compile the file using "/usr/openwin/bin/msgfmt" into a
message object file (.mo) and put this file into the proper
directory (e.g.
/usr/openwin/share/locale/fr/LC_MESSAGES/SUNW_WST_LIBXVIEW_3200.mo
for frensh translations). Then, if you set the environment
variable LANG correctly (e.g. export LANG=fr), you will
automaticly get the right messages und butten text in XView
applications.

(c) 2005 by Martin Gr�fe
AuM.Graefe@t-online.de
